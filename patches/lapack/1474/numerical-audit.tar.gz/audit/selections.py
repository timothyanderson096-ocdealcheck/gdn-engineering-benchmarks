"""Independent direct partial-block and alternate-eigenvalue validation for DSTEIN."""
import argparse
import csv
import ctypes as ct
from abi import Library, integer_type, integer_dtype
from pathlib import Path

import numpy as np

from sweep import pattern, ptr, scalar


def run(lib, n, mode):
    d,e=pattern((n-1)//4,1e-10,1e-120 if n==13 else 1e-30)
    e=np.r_[e,0.]
    mat=np.diag(e[:-1],1)+np.diag(e[:-1],-1)
    ref_vals=np.linalg.eigvalsh(mat)
    work=np.zeros(8*n);iw=np.zeros(6*n,integer_dtype)
    blocks=np.ones(n,integer_dtype);splits=np.zeros(n,integer_dtype);splits[0]=n
    w=np.zeros(n);z=np.zeros((n,n),order='F');ifail=np.zeros(n,integer_dtype)
    info=integer_type(); count=integer_type(n); nb=integer_type(1)
    if mode=='DSTERF':
        w=d.copy(); ee=e.copy()
        lib.dsterf_(scalar(integer_type,n),ptr(w),ptr(ee),ct.byref(info))
    else:
        upper=.5 if mode.endswith('half') else 1.5
        vals=(scalar(ct.c_double,-1.5),scalar(ct.c_double,upper),scalar(integer_type,0),scalar(integer_type,0))
        ref_vals=ref_vals[(ref_vals>-1.5)&(ref_vals<=upper)]
        if mode.startswith('DSTEVX'):
            dd,ee=d.copy(),e.copy()
            lib.dstevx_(b'V',b'V',scalar(integer_type,n),ptr(dd),ptr(ee),*vals,scalar(ct.c_double,0),
                        ct.byref(count),ptr(w),ptr(z),scalar(integer_type,n),ptr(work),ptr(iw),ptr(ifail),
                        ct.byref(info),ct.c_size_t(1),ct.c_size_t(1))
        else:
            lib.dstebz_(b'V',b'B',scalar(integer_type,n),*vals,scalar(ct.c_double,0),ptr(d),ptr(e),
                        ct.byref(count),ct.byref(nb),ptr(w),ptr(blocks),ptr(splits),ptr(work),ptr(iw),
                        ct.byref(info),ct.c_size_t(1),ct.c_size_t(1))
    if not mode.startswith('DSTEVX'):
        if info.value:
            raise ValueError((mode,'eigenvalue computation failed',info.value))
        lib.dstein_(scalar(integer_type,n),ptr(d),ptr(e),ct.byref(count),ptr(w),ptr(blocks),ptr(splits),
                    ptr(z),scalar(integer_type,n),ptr(work),ptr(iw),ptr(ifail),ct.byref(info))
    m=count.value;w=w[:m];z=z[:,:m]
    if len(ref_vals)!=m:
        raise ValueError((mode,m,len(ref_vals)))
    return dict(n=n,mode=mode,m=m,info=info.value,ifail_count=np.count_nonzero(ifail),
                abs_eigenvalue_error=np.max(np.abs(ref_vals-w)),abs_residual=np.max(np.abs(mat@z-z*w)),
                orth_error=np.max(np.abs(z.T@z-np.eye(m))))


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('library',type=Path)
    cli.add_argument('--out',type=Path,required=True)
    args=cli.parse_args()
    lib=Library(str(args.library.resolve()))
    rows=[run(lib,n,mode) for n in (13,45) for mode in ('DSTERF','DSTEBZ-full','DSTEBZ-half','DSTEVX-full','DSTEVX-half')]
    with args.out.open('w',newline='') as target:
        writer=csv.DictWriter(target,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
    for r in rows:
        print(r['n'],r['mode'],r['m'],r['info'],f"{r['abs_residual']:.3g}",f"{r['orth_error']:.3g}")
