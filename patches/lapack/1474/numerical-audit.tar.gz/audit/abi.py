"""Select LAPACK ABI once per audit process."""
import ctypes
import os

import numpy

bits = os.environ.get("LAPACK_AUDIT_INTEGER", "32")
if bits not in ("32", "64"):
    raise ValueError("LAPACK_AUDIT_INTEGER must be 32 or 64")
integer_type = ctypes.c_int32 if bits == "32" else ctypes.c_int64
integer_dtype = numpy.int32 if bits == "32" else numpy.int64


class Library:
    def __init__(self, path):
        self.library = ctypes.CDLL(str(path))

    def __getattr__(self, symbol):
        if not symbol.endswith("_"):
            raise AttributeError(symbol)
        suffix = "_64_" if bits == "64" else "_"
        return getattr(self.library, symbol[:-1] + suffix)
