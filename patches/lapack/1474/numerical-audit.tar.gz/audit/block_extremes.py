"""Check small and large eigenblocks against their *own* norm, in both block orders."""
import argparse
import csv
import ctypes as ct
from abi import Library, integer_type, integer_dtype
from pathlib import Path

import numpy as np

from homogeneity import factor_inputs
from sweep import pattern, ptr, scalar


def run(lib,p,j):
    single=p in 'sc'; real=np.float32 if single else np.float64
    powers=(55,-65) if single else (510,-550)
    if j:powers=powers[::-1]
    d0,e0=pattern(3,1e-4 if single else 1e-10,1e-16 if single else 1e-120)
    d0,e0,w0,_,_=factor_inputs(lib,d0,e0,single)
    n0=len(d0); n=2*n0+1
    d=np.r_[np.ldexp(d0,powers[0]),real(1.),np.ldexp(d0,powers[1])]
    e=np.r_[np.ldexp(e0,powers[0]),real(0),np.ldexp(e0,powers[1])]
    w=np.r_[np.ldexp(w0,powers[0]),real(1.),np.ldexp(w0,powers[1])]
    blocks=np.repeat(np.array([1,2,3],integer_dtype),[n0,1,n0])
    splits=np.zeros(n,integer_dtype);splits[:3]=[n0,n0+1,n]
    z=np.zeros((n,n),order='F',dtype={'d':float,'s':np.float32,'c':np.complex64,'z':complex}[p])
    iw=np.zeros(5*n,integer_dtype); work=np.zeros(5*n,real); ifail=np.zeros(n,integer_dtype); info=integer_type()
    getattr(lib,p+'stein_')(scalar(integer_type,n),ptr(d),ptr(e),scalar(integer_type,n),ptr(w),ptr(blocks),ptr(splits),
        ptr(z),scalar(integer_type,n),ptr(work),ptr(iw),ptr(ifail),ct.byref(info))
    mat=np.diag(d0.astype(float))+np.diag(e0[:-1].astype(float),1)+np.diag(e0[:-1].astype(float),-1)
    z=z.astype(complex)
    with np.errstate(invalid='ignore'):
        resid=[float(np.max(np.abs(mat@z[s,s]-z[s,s]*w0))) for s in (slice(0,n0),slice(n0+1,n))]
        off=max(np.max(np.abs(z[0:n0,n0:])), np.max(np.abs(z[n0:,:n0])),
                np.max(np.abs(z[n0,n0+1:])),np.max(np.abs(z[n0+1:,n0])))
        orth=float(np.max(np.abs(z.conj().T@z-np.eye(n))))
    tol=200*n*np.finfo(real).eps
    return dict(precision=p,first_scale_2=powers[0],last_scale_2=powers[1],info=info.value,
                ifail_count=np.count_nonzero(ifail),first_block_resid=resid[0],last_block_resid=resid[1],
                off_block_leakage=off,orth_error=orth,passed=all(np.isfinite(x) and x<=tol for x in [*resid,off,orth]))


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('library',type=Path)
    cli.add_argument('--out',type=Path,required=True);args=cli.parse_args()
    lib=Library(str(args.library.resolve()));rows=[run(lib,p,j) for p in 'dscz' for j in (0,1)]
    with args.out.open('w',newline='') as out:
        w=csv.DictWriter(out,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    print('passed',sum(r['passed'] for r in rows),'of',len(rows))
