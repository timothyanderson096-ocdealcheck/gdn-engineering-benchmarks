"""Direct two-by-two STEIN systems with exactly known eigenpairs down to the smallest subnormal."""
import argparse
import csv
import ctypes as ct
from abi import Library, integer_type, integer_dtype
import multiprocessing as mp
from pathlib import Path

import numpy as np

from sweep import ptr, scalar


def solve(binary, p, x, queue):
    lib=Library(str(binary)); dtype=np.float32 if p in 'sc' else np.float64
    d=np.zeros(2,dtype); e=np.array([x,0.],dtype); w=np.array([-x,x],dtype)
    blocks=np.array([1,1],integer_dtype); splits=np.array([2,0],integer_dtype)
    z=np.zeros((2,2),order='F',dtype={'d':float,'s':np.float32,'c':np.complex64,'z':complex}[p])
    work=np.zeros(10,dtype); iw=np.zeros(10,integer_dtype); ifail=np.zeros(2,integer_dtype); info=integer_type()
    getattr(lib,p+'stein_')(scalar(integer_type,2),ptr(d),ptr(e),scalar(integer_type,2),ptr(w),ptr(blocks),ptr(splits),
        ptr(z),scalar(integer_type,2),ptr(work),ptr(iw),ptr(ifail),ct.byref(info))
    # The normalized exact matrix and eigenvalues need no arithmetic on subnormals.
    zz=z.astype(complex)
    residual=float(np.max(np.abs(zz[::-1,:]-zz*np.array([-1.,1.]))))
    orth=float(np.max(np.abs(zz.conj().T@zz-np.eye(2))))
    queue.send(dict(precision=p,magnitude=float(x),info=info.value,ifail=np.count_nonzero(ifail),resid=residual,orth=orth))


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('library',type=Path);cli.add_argument('--out',type=Path,required=True)
    cli.add_argument('--precision',default='dscz');args=cli.parse_args()
    records=[]
    for p in args.precision:
        dtype=np.float32 if p in 'sc' else np.float64
        tiny=np.finfo(dtype).smallest_subnormal
        for x in ([1e-310,1e-320,tiny] if p in 'dz' else [1e-39,1e-43,tiny]):
            rx,tx=mp.get_context('fork').Pipe(duplex=False)
            proc=mp.get_context('fork').Process(target=solve,args=(args.library.resolve(),p,dtype(x),tx))
            proc.start();tx.close();proc.join()
            try:
                r=rx.recv()
            except EOFError:
                r=dict(precision=p,magnitude=float(dtype(x)),info='STOP',ifail='',resid='',orth='')
            rx.close();records.append(r)
    with args.out.open('w',newline='') as out:
        w=csv.DictWriter(out,fieldnames=records[0]);w.writeheader();w.writerows(records)
    print(records)
