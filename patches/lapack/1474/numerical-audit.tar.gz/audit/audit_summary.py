"""Summarize all independent tests, flag false success, and retain empirical timings."""
import argparse
import csv
import json
from pathlib import Path

import numpy as np


def read(dir_, name):
    with (dir_/(name+'.csv')).open(newline='') as f:
        return list(csv.DictReader(f))


def report(dir_):
    meta=json.loads((dir_/'summary.json').read_text())
    main=read(dir_,'sweep')
    coarse=[r for r in main if r['group']=='coarse']
    report=dict(native_sha256=meta['lib_sha256'],families=meta['summary'],main=len(main),
        main_bad=sum(r['quality_pass']!='True' for r in main),
        nonfinite=sum(r.get('finite')=='False' for r in main),
        info_nonzero=sum(r['info']!='0' for r in main), ifail_nonzero=sum(r['ifail_count']!='0' for r in main),
        coarse_tested=len(coarse),coarse_bad=sum((r['quality_pass'],r['info'],r['ifail_count'])!=('True','0','0') for r in coarse),
        coarse_worst_residual_to_abstol=max(float(r['resid_col2'])/float(r['coarse_tol_norm']) for r in coarse),
        coarse_worst_input_eigenerror_to_abstol=max(float(r['eigerr_norm'])/float(r['coarse_tol_norm']) for r in coarse))
    for kind in ('homogeneity','tiny_exact','block_extremes','selections'):
        rows=read(dir_,kind)
        failures=sum(
            (r.get('passed')=='False' or r['info']!='0' or r.get('ifail',r.get('ifail_count','0'))!='0' or
             (kind=='tiny_exact' and (not np.isfinite(float(r['resid'])) or not np.isfinite(float(r['orth'])) or
              max(float(r['resid']),float(r['orth'])) > (1e-5 if r['precision'] in 'sc' else 1e-12))) or
             (kind=='selections' and max(float(r['abs_residual']),float(r['orth_error']))>1e-10))
            for r in rows)
        report[kind]=dict(total=len(rows),bad=failures)
    if (dir_/'timing.csv').exists():
        groups={}
        for r in read(dir_,'timing'):
            groups.setdefault(f"n{r['n']}-m{r['m']}-split{r['split']}",[]).append(r)
        report['paired_timing']={k:dict(
            median_stock_ms=float(np.median([float(r['stock_ms']) for r in rs])),
            median_candidate_ms=float(np.median([float(r['candidate_ms']) for r in rs])),
            ratio_quartiles=np.quantile([float(r['ratio']) for r in rs],[.25,.5,.75]).tolist(),
            trials=len(rs), calls_per_batch=int(rs[0].get('calls_per_batch',1))) for k,rs in groups.items()}
    return report


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__);cli.add_argument('directories',nargs='+',type=Path)
    cli.add_argument('--out',required=True,type=Path);args=cli.parse_args()
    args.out.write_text(json.dumps({p.name:report(p) for p in args.directories},indent=2)+'\n')
