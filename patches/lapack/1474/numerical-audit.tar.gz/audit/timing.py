"""Interleaved DSTEIN-only timings using fixed identical DSTEBZ eigenpairs and preallocated outputs."""
import argparse
import ctypes as ct
from abi import Library, integer_type, integer_dtype
import csv
import os
import time
from pathlib import Path

import numpy as np

from sweep import scalar, ptr


def prepare(libs,n,m,split=False):
    d=np.random.default_rng(1705).normal(size=n)
    e=np.r_[np.random.default_rng(1706).uniform(.1,1.,n-1),0.]
    if split:
        e[63::64]=0.
    w=np.zeros(n); b=np.zeros(n,integer_dtype); chunks=b.copy()
    work=np.zeros(5*n); integers=np.zeros(5*n,integer_dtype); info=integer_type()
    num=integer_type(); count_blocks=integer_type()
    libs[0].dstebz_(b'A',b'B',scalar(integer_type,n),scalar(ct.c_double,0),scalar(ct.c_double,0),scalar(integer_type,0),
                    scalar(integer_type,0),scalar(ct.c_double,-1),ptr(d),ptr(e),ct.byref(num),ct.byref(count_blocks),
                    ptr(w),ptr(b),ptr(chunks),ptr(work),ptr(integers),ct.byref(info),ct.c_size_t(1),ct.c_size_t(1))
    assert info.value==0 and num.value==n
    if m!=n:
        # Every case with a subset here has one block. Select consecutive central eigenpairs.
        lo=(n-m)//2
        w=w[lo:lo+m].copy(); b=b[lo:lo+m].copy()
    z=np.zeros((n,m),order='F');ifail=np.zeros(m,integer_dtype)
    arguments=[scalar(integer_type,n),ptr(d),ptr(e),scalar(integer_type,m),ptr(w),ptr(b),ptr(chunks),ptr(z),
               scalar(integer_type,n),ptr(work),ptr(integers),ptr(ifail),ct.byref(info)]
    # ctypes void-pointer arguments do not retain the NumPy buffers.
    backing=(d,e,w,b,chunks,z,work,integers,ifail)
    def run(lib):
        assert backing[0].size==n
        start=time.process_time_ns()
        lib.dstein_(*arguments)
        elapsed=time.process_time_ns()-start
        assert info.value==0 and np.isfinite(z).all()
        return elapsed*1e-6
    return run


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('stock',type=Path);cli.add_argument('candidate',type=Path)
    cli.add_argument('--out',type=Path,required=True); args=cli.parse_args()
    libs=[Library(str(p.resolve())) for p in [args.stock,args.candidate]]
    if hasattr(os,'sched_getaffinity'):
        os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
    observations=[]
    for n,m,split in [(256,256,False),(512,32,False),(512,512,False),(512,512,True)]:
        run=prepare(libs,n,m,split)
        base_time=run(libs[0])
        # Aggregate short calls to reduce scheduler and clock-frequency noise.
        batch=max(1,round(25/max(base_time,.001)))
        def batch_ms(lib):
            return sum(run(lib) for _ in range(batch))/batch
        for _ in range(3):
            for lib in libs:batch_ms(lib)
        for trial in range(25):
            order=[0,1] if trial%2==0 else [1,0]
            vals={}
            for k in order:vals[k]=batch_ms(libs[k])
            observations.append(dict(n=n,m=m,split=split,trial=trial,calls_per_batch=batch,stock_ms=vals[0],candidate_ms=vals[1],
                                     ratio=vals[1]/vals[0]))
        group=observations[-25:]
        ratios=[r['ratio'] for r in group]
        print(n,m,split,'stock ms',np.median([r['stock_ms'] for r in group]),
              'candidate ms',np.median([r['candidate_ms'] for r in group]),'ratio p25/50/75',np.quantile(ratios,[.25,.5,.75]))
    with args.out.open('w',newline='') as dest:
        writ=csv.DictWriter(dest,fieldnames=observations[0]);writ.writeheader();writ.writerows(observations)
