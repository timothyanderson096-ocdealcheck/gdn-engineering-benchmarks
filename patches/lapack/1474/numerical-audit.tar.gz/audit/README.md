# Independent LAPACK inverse-iteration audit

The test programs load a named native shared library directly and call the Fortran routines. The main suite checks 988 routine/matrix combinations. DSTEIN and ZSTEIN each see 262 matrices. SSTEIN and CSTEIN each see 232 matrices scaled to probe the exponent range of binary32. The same real tridiagonal matrices underlie a real and complex-output pair. These counts describe reproducible numerical tests and do not represent a frequency estimate for users' matrices.

## Results

On the pristine reference-Fortran build from commit `12612ecb8c4e1efa32c7830d0fc93c638e9e3403`, 263 of 1,138 checks returned inaccurate or nonfinite eigenvectors with INFO=0 and clear IFAIL. The final patch passed all 1,138. The 32-bit and 64-bit Fortran integer interfaces produced byte-identical numerical CSV results. The 64-bit runs use the actual suffixed symbols and 64-bit INTEGER arrays throughout. Repeated real/complex variants, build interfaces and different entry points for the same matrix are identified in the data.

| Independent protocol | Cases per integer interface | Stock failures | Final failures |
| --- | ---: | ---: | ---: |
| Coupling, cluster, sign, scale, split, random and coarse-shift sweep | 988 | 152 | 0 |
| Exact power-of-two scale transformations | 120 | 86 | 0 |
| Exact two-by-two inputs down to the smallest subnormal | 12 | 12 | 0 |
| Mixed-scale blocks checked using each block's own scale | 8 | 8 | 0 |
| Value ranges and alternate source of eigenvalues | 10 | 5 | 0 |

The maximum absolute entries of TZ−ZW on the published 13×13 and 45×45 examples fell from **0.353548** and **0.267261** to **5.55e−17** for both. The corresponding orthogonality errors fell from 0.272336 and 0.285714 to 5.55e−16 and 6.66e−16. Independently bracketed true eigenvalues and supplied eigenvalues differ by at most 5.56e−17. Across all 48 coarse controls the candidate reported INFO=0 and clear IFAIL. The worst column residual was below 0.405 times the requested absolute eigenvalue tolerance.

**Performance tradeoff.** On the LP64 build with single-threaded reference BLAS, the median paired CPU time for DSTEIN increased by 14.1% for 256 vectors of an irreducible 256 matrix, 15.5% for 32 central vectors of a 512 matrix, 12.8% for all 512 vectors, and 20.2% for all vectors of an eight-block 512 matrix. The ratios measure the inverse-iteration routine alone on four synthetic inputs. Compiler, BLAS, CPU and matrix spectrum can affect them. Raw per-batch measurements and quartiles are included.

`verification.json` contains per-ABI counts, the tested binaries' SHA-256 digests and timings. The final LP64 binary's SHA-256 is `78334151a24d6eba119b882bc245bf2ec16db21b92556956778ac8a567da14d3`. The final 64-bit integer binary is `e3759e1787ee72bce530377c4191bb04a453403e8bcae228dc779a3aac8b5184`.

## Cases and independent reference

The two published double inputs use zero diagonals and the repeated four-term subdiagonal pattern [1e−10, 1e−10, 1, t]. N=13 uses t=1e−120 and N=45 uses t=1e−30. Our single precision analogues have N=13 or 45, first and second couplings 1e−4 and terminal couplings 1e−16 or 1e−9 respectively. Other cases vary matrix sizes and coupling exponents, use diagonal translations, change signs, scale the full matrix, introduce exact split blocks including equal-spectrum twins, form tightly clustered spectra, and draw deterministic ordinary random tridiagonals. DSTEIN's inputs come from DSTEBZ in block order. For high scales above STEBZ's documented safe bound, STEBZ sees a normalized equivalent matrix and STEIN receives the shifts and original matrix restored to their original scale.

For every output we directly compute TZ−ZW, Z*Z−I, normwise maximum column residual, each vector's Rayleigh residual, and leakage outside the independently computed reference cluster subspaces. The reference explicitly forms the dense matrix and uses NumPy's divide-and-conquer eigh algorithm. Arbitrary vector signs and arbitrary bases inside unresolved clusters do not affect the leakage metric. A separate Sturm count with 330 decimal digits and 90 bisections per eigenvalue validates the two published input spectra without calling LAPACK.

The predeclared diagnostic bound for ordinary cases is 200·n·machine_epsilon for the largest normalized residual 2-norm and orthogonality error. For intentionally coarse shifts, tolerance/||T||∞ is added to the residual bound and twice that amount to the orthogonality bound. The CSV preserves the actual metrics without cutoff. The twelve coarse controls in each routine use ABSTOL of 1e−4, 1e−3 and 1e−2 on sizes 5, 9, 15 and 25. The zero matrices of order one and nine exercise zero-norm normalization. tiny_exact.py checks both members of an exactly known two-by-two spectrum down to the smallest subnormal. block_extremes.py separates two adversarial blocks by an isolated singleton and verifies each block against its own norm. The double-precision block magnitude ratio reaches 2^1060.

selections.py independently runs complete and restricted value intervals via DSTEVX and via separate DSTEBZ and DSTEIN calls. It also passes DSTERF eigenvalues to DSTEIN on the originals. homogeneity.py is an additional 120-call stress protocol, separate from the main suite. It scales d, e and supplied W by exact powers of two while retaining splitting metadata from the original matrix. A worker process for each call contains any LAPACK error handler that stops the process. timing.py measures only DSTEIN with fixed, precomputed eigenpairs and reusable allocated outputs, 3 warmup batches and 25 paired batches, targeting 25 ms of stock work per batch, alternating execution order on one pinned CPU. Timing is process CPU time; operating-system and compiler effects limit generalization.

## Reproduction

Use Python 3.10 or later, NumPy, and GNU-compatible reference LAPACK/BLAS shared libraries. The default wrapper loads LP64 symbols. Set LAPACK_AUDIT_INTEGER=64 to load suffixed 64-bit integer symbols and matching storage. Other symbol and character ABIs may need a different wrapper.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export LD_LIBRARY_PATH=/path/to/reference-lapack/lib
python sweep.py /path/to/reference-lapack/lib/liblapack.so --out baseline
python selections.py /path/to/reference-lapack/lib/liblapack.so --out baseline/selections.csv
python homogeneity.py /path/to/reference-lapack/lib/liblapack.so --out baseline/homogeneity.csv
python tiny_exact.py /path/to/reference-lapack/lib/liblapack.so --out baseline/tiny_exact.csv
python block_extremes.py /path/to/reference-lapack/lib/liblapack.so --out baseline/block_extremes.csv

export LD_LIBRARY_PATH=/path/to/candidate-lapack/lib
python sweep.py /path/to/candidate-lapack/lib/liblapack.so --out final
python selections.py /path/to/candidate-lapack/lib/liblapack.so --out final/selections.csv
python homogeneity.py /path/to/candidate-lapack/lib/liblapack.so --out final/homogeneity.csv
python tiny_exact.py /path/to/candidate-lapack/lib/liblapack.so --out final/tiny_exact.csv
python block_extremes.py /path/to/candidate-lapack/lib/liblapack.so --out final/block_extremes.csv
python timing.py /path/to/reference-lapack/lib/liblapack.so /path/to/candidate-lapack/lib/liblapack.so --out final/timing.csv
python audit_summary.py baseline final --out verification.json
```

The recorded before-and-after CSVs are in `baseline` and `final`. Their large `sweep.csv` files are gzip-compressed. The corresponding numerical CSVs for the 64-bit integer interface compared byte for byte with these files. Each directory also includes its 64-bit binary identification as `summary64.json`.
