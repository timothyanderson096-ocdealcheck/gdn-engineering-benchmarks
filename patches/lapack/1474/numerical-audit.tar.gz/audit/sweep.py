"""Exercise STEBZ -> {S,D,C,Z}STEIN from an explicitly named native LP64 library.

The quality audit uses direct algebraic residuals, dense divide-and-conquer
eigenpairs, and decimal-arithmetic Sturm bracketing for the two published cases.
Set BLAS threads to 1. The script never writes the LAPACK source or library.
"""
import argparse
import csv
import ctypes as ct
from abi import Library, integer_type, integer_dtype
import hashlib
import json
import math
from collections import Counter
from dataclasses import dataclass
from decimal import Decimal, localcontext
from pathlib import Path

import numpy as np


@dataclass
class Case:
    name: str
    kind: str
    d: np.ndarray
    e: np.ndarray
    abstol: float = -1


def pattern(k, c, t):
    return np.zeros(4*k+1), np.tile([c,c,1.0,t],k)


def matrices(single):
    rng = np.random.default_rng(1474)
    # Couplings chosen to span the mantissa and exponent regimes of each type.
    power_c = [2, 3, 4, 5, 6, 7] if single else [6,8,10,12,14,16]
    power_t = [3,6,9,12,16] if single else [8,20,30,60,120,150]
    anchors = ((3,4,16),(11,4,9)) if single else ((3,10,120),(11,10,30))
    for k,c,t in anchors:
        yield Case(f"anchor-n{4*k+1}", "anchor", *pattern(k,10.0**-c,10.0**-t))
    for k in (1,3,6,11,16):
        for c in power_c:
            for t in power_t:
                if (k,c,t) not in anchors:
                    yield Case(f"k{k}-c{c}-t{t}", "coupling_grid", *pattern(k,10.0**-c,10.0**-t))
    for k,c,t in anchors:
        d,e = pattern(k,10.0**-c,10.0**-t)
        for i in range(5):
            signs = rng.choice([-1.,1.],len(e))
            yield Case(f"sign-n{len(d)}-{i}", "sign", d, e*signs)
        for power in ([-12,-6,-2,2,6,12] if single else [-80,-40,-4,4,40,80]):
            scale=10.0**power
            yield Case(f"scale-n{len(d)}-e{power}", "scale", d*scale, e*scale)
        for j, shift in enumerate([0.01, 1., -1., 100.]):
            yield Case(f"shift-n{len(d)}-{j}", "translation", d + shift, e)
        # Exact zeros produce independent, nonsymmetric-size blocks separated by singletons.
        d2=np.r_[3., d, 5., d+.25, -3.]
        e2=np.r_[0., e, 0.,0.,e,0.]
        yield Case(f"splits-n{len(d)}", "split", d2, e2)
    for j in range(12):
        n=[7,17,33,48][j%4]
        d=rng.normal(size=n); e=rng.normal(size=n-1)
        yield Case(f"random-{j}", "random", d,e)
        # Exactly repeated eigenvalues across two equal blocks.
        yield Case(f"twins-{j}", "split", np.r_[d,d], np.r_[e,0.,e])
        # Numerically narrow cluster near 1 with off-diagonal signs and a separated low/high end.
        spread=(1e-4 if single else 1e-11)
        cd=1.+rng.normal(size=n)*spread; cd[0]=-1.; cd[-1]=3.
        ce=rng.normal(size=n-1)*spread
        yield Case(f"cluster-{j}", "cluster",cd,ce)
    for n in (5,9,15,25):
        # Well-separated eigenspaces. Three shifts have intentional input uncertainty.
        d=np.linspace(-1.,1.,n); e=np.full(n-1,.035)
        for tol in (.0001,.001,.01):
            yield Case(f"coarse-n{n}-tol{tol}", "coarse",d,e,tol)
    yield Case("one","edge",np.array([0.]),np.empty(0))
    yield Case("zero","edge",np.zeros(9),np.zeros(8))


def scalar(kind, number):
    return ct.byref(kind(number))


def ptr(a):
    return ct.c_void_p(a.ctypes.data)


def invoke(lib, case, precision):
    single=precision in 'sc'
    scalar_type=ct.c_float if single else ct.c_double
    dtype=np.float32 if single else np.float64
    vec_dtype={'s':np.float32,'d':np.float64,'c':np.complex64,'z':np.complex128}[precision]
    d=np.array(case.d,dtype=dtype)
    e=np.array(np.r_[case.e,0.],dtype=dtype)
    n=len(d)
    w=np.zeros(n,dtype=dtype); blocks=np.zeros(n,integer_dtype); splits=blocks.copy()
    work=np.zeros(5*n,dtype); iw=np.zeros(5*n,integer_dtype)
    count,nb,info=integer_type(),integer_type(),integer_type()
    # STEBZ documents an upper input-scale bound. Obtain high-scale shifts
    # from an equivalent matrix normalized only for STEBZ, then restore them
    # before passing the original unscaled matrix into STEIN.
    max_elem=max(float(np.max(np.abs(d))), float(np.max(np.abs(e))))
    finfo=np.finfo(dtype)
    bisection_limit=math.sqrt(float(finfo.max)) * float(finfo.tiny)**.25
    bz_scale=max_elem if max_elem>bisection_limit else 1.
    bz_d, bz_e = d / dtype(bz_scale), e / dtype(bz_scale)
    stebz=getattr(lib,('s' if single else 'd')+'stebz_')
    stebz(b'A',b'B',scalar(integer_type,n),scalar(scalar_type,0),scalar(scalar_type,0),scalar(integer_type,0),
          scalar(integer_type,0),scalar(scalar_type,case.abstol/bz_scale),ptr(bz_d),ptr(bz_e),ct.byref(count),ct.byref(nb),
          ptr(w),ptr(blocks),ptr(splits),ptr(work),ptr(iw),ct.byref(info),ct.c_size_t(1),ct.c_size_t(1))
    if info.value!=0 or count.value!=n:
        raise ValueError(f"STEBZ count={count.value}, INFO={info.value}")
    w *= dtype(bz_scale)
    z=np.zeros((n,n),order='F',dtype=vec_dtype)
    ifail=np.zeros(n,dtype=integer_dtype)
    getattr(lib,precision+'stein_')(scalar(integer_type,n),ptr(d),ptr(e),ct.byref(count),
        ptr(w),ptr(blocks),ptr(splits),ptr(z),scalar(integer_type,n),ptr(work),ptr(iw),ptr(ifail),ct.byref(info))
    order=np.argsort(w,kind='stable')
    return d.astype(float),e[:-1].astype(float),w[order].astype(float),z[:,order],info.value,ifail,nb.value


def decimal_spectrum(d,e):
    """Independent high-precision eigenvalue brackets, with endpoint width below 2^-85."""
    with localcontext() as context:
        context.prec=330
        dd=[Decimal.from_float(float(i)) for i in d]
        ee=[Decimal.from_float(float(i))**2 for i in e]
        bound=max(abs(v) for v in d)+2*max(abs(v) for v in e)+1
        def count(mid):
            q=dd[0]-mid
            c=0
            for i in range(len(dd)):
                if q==0:
                    q=Decimal('-1e-320')
                c += int(q < 0)
                if i+1<len(dd):
                    q=dd[i+1]-mid-ee[i]/q
            return c
        pairs={}
        values=[]
        for i in range(len(dd)):
            lo,hi=Decimal(-float(bound)),Decimal(float(bound))
            for _ in range(90):
                mid=(lo+hi)/2
                if mid not in pairs:
                    pairs[mid]=count(mid)
                if pairs[mid]<=i:
                    lo=mid
                else:
                    hi=mid
            values.append(float((lo+hi)/2))
        return np.array(values)


def metrics(lib,case,precision):
    d,e,w,z,info,ifail,nb=invoke(lib,case,precision)
    z=z.astype(complex if precision in 'cz' else float)
    n=len(d)
    mat=np.diag(d)+np.diag(e,1)+np.diag(e,-1)
    norm=float(np.linalg.norm(mat,np.inf)) or 1.
    scaled=mat/norm
    ref,refs=np.linalg.eigh(scaled)
    eps=np.finfo(np.float32 if precision in 'sc' else np.float64).eps
    abstol=max(0.,case.abstol)/norm
    normalized=w/norm
    vals_err=float(np.max(np.abs(ref-normalized)))
    row=dict(precision=precision,case=case.name,group=case.kind,n=n,blocks=nb,
             info=info,ifail_count=np.count_nonzero(ifail),ifail_indices=" ".join(map(str,ifail[ifail!=0])),
             finite=bool(np.isfinite(z).all()),eigerr_norm=vals_err,coarse_tol_norm=abstol)
    if case.kind=='anchor' and precision=='d':
        dec=decimal_spectrum(d,e)
        row['decimal_eigerr_abs']=float(np.max(np.abs(dec-w)))
        row['decimal_dense_disagreement_abs']=float(np.max(np.abs(dec-ref*norm)))
    if not row['finite']:
        row.update(quality_pass=False)
        return row
    resid=scaled@z-z*normalized
    gram=z.conj().T@z
    row['resid_abs']=float(np.max(np.abs(resid)))*norm
    row['resid_norm']=float(np.max(np.abs(resid)))
    row['resid_col2']=float(np.linalg.norm(resid,axis=0).max())
    row['orth_max']=float(np.max(np.abs(gram-np.eye(n))))
    ray=np.real(np.sum(z.conj()*(scaled@z),axis=0))
    row['rayleigh_resid_col2']=float(np.linalg.norm(scaled@z-z*ray,axis=0).max())
    # Measure distance to the reference subspace of each resolvable cluster.
    # The split threshold deliberately groups approximate multiplicities.
    gap=max(128*n*eps,1e-6,4*abstol)
    cuts=np.r_[0,1+np.where(np.diff(ref)>gap)[0],n]
    angle=0.
    for i,j in zip(cuts,cuts[1:]):
        q=refs[:,i:j]; cand=z[:,i:j]
        outside=cand-q@(q.conj().T@cand)
        angle=max(angle,float(np.linalg.norm(outside,'fro')/math.sqrt(j-i)))
    row['ref_cluster_leakage']=angle
    row['reference_resid_col2']=float(np.linalg.norm(scaled@refs-refs*ref,axis=0).max())
    # Loose informational guard catches macroscopic silent failures. Coarse input
    # eigenvalues are allowed the requested uncertainty. Report all raw values.
    threshold=200*n*eps
    row['quality_pass']=bool(row['resid_col2']<=threshold+abstol and row['orth_max']<=threshold+2*abstol)
    return row


def main():
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('library',type=Path)
    cli.add_argument('--out',type=Path,required=True)
    cli.add_argument('--precision',default='dszc')
    args=cli.parse_args()
    lib=Library(str(args.library.resolve()))
    rows=[]
    for p in args.precision:
        for case in matrices(p in 'sc'):
            try:
                rows.append(metrics(lib,case,p))
            except (ValueError, np.linalg.LinAlgError) as error:
                rows.append(dict(precision=p,case=case.name,group=case.kind,error=str(error),quality_pass=False))
    args.out.mkdir(parents=True,exist_ok=True)
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with (args.out/'sweep.csv').open('w',newline='') as out:
        writer=csv.DictWriter(out,fieldnames=keys)
        writer.writeheader();writer.writerows(rows)
    summary={}
    for p in args.precision:
        g=[r for r in rows if r['precision']==p]
        bad=[r for r in g if not r.get('quality_pass')]
        summary[p]=dict(total=len(g),bad=len(bad),silent_bad=sum(r.get('info')==0 for r in bad),
                        info_nonzero=sum(r.get('info',0)!=0 for r in g),not_finite=sum(r.get('finite') is False for r in g),
                        failed_by_group=dict(Counter(r['group'] for r in bad)),errors=sum('error' in r for r in g))
    report=dict(summary=summary,library=args.library.name,lib_sha256=hashlib.sha256(args.library.read_bytes()).hexdigest())
    (args.out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
    for r in rows:
        if r['group']=='anchor' and r['precision']=='d':
            print(r)


if __name__=='__main__':
    main()
