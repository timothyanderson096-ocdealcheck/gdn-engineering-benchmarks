"""Direct STEIN homogeneity checks preserving the eigenvalue and matrix significands."""
import argparse
import csv
import ctypes as ct
from abi import Library, integer_type, integer_dtype
import multiprocessing as mp
from pathlib import Path

import numpy as np

from sweep import pattern, ptr, scalar


def factor_inputs(lib,d,e,single):
    n=len(d); dtype=np.float32 if single else np.float64; ct_real=ct.c_float if single else ct.c_double
    d=d.astype(dtype);e=np.r_[e,0.].astype(dtype)
    w=np.zeros(n,dtype); blocks=np.zeros(n,integer_dtype); splits=blocks.copy()
    work=np.zeros(5*n,dtype);iw=np.zeros(5*n,integer_dtype)
    m=integer_type();nb=integer_type();info=integer_type()
    getattr(lib,('s' if single else 'd')+'stebz_')(b'A',b'B',scalar(integer_type,n),scalar(ct_real,0),
        scalar(ct_real,0),scalar(integer_type,0),scalar(integer_type,0),scalar(ct_real,-1),
        ptr(d),ptr(e),ct.byref(m),ct.byref(nb),ptr(w),ptr(blocks),ptr(splits),ptr(work),ptr(iw),ct.byref(info),
        ct.c_size_t(1),ct.c_size_t(1))
    assert info.value==0 and m.value==n
    return d,e,w,blocks,splits


def run(lib,out,precision):
    rows=[]
    for p in precision:
        single=p in 'sc'
        for label,d,e in [('published13',*pattern(3,1e-4 if single else 1e-10,1e-16 if single else 1e-120)),
                          ('published45',*pattern(11,1e-4 if single else 1e-10,1e-9 if single else 1e-30)),
                          ('ordinary',np.linspace(-1.5,1.,13),np.full(12,.25))]:
            d,e,w,blocks,splits=factor_inputs(lib,d,e,single)
            n=len(d)
            for exponent in ([-80,-64,-32,-16,0,16,32,64,80] if single else [-600,-512,-384,-256,-128,0,128,256,384,512,600]):
                dd,ee,ww=[np.ldexp(a,exponent) for a in (d,e,w)]
                z=np.zeros((n,n),order='F',dtype={'d':float,'s':np.float32,'c':np.complex64,'z':complex}[p])
                iw=np.zeros(5*n,integer_dtype);work=np.zeros(5*n,d.dtype);ifail=np.zeros(n,integer_dtype);info=integer_type()
                def compute(tx):
                    getattr(lib,p+'stein_')(scalar(integer_type,n),ptr(dd),ptr(ee),scalar(integer_type,n),ptr(ww),
                        ptr(blocks),ptr(splits),ptr(z),scalar(integer_type,n),ptr(work),ptr(iw),ptr(ifail),ct.byref(info))
                    mat=np.diag(d.astype(float))+np.diag(e[:-1].astype(float),1)+np.diag(e[:-1].astype(float),-1)
                    norm=np.linalg.norm(mat,np.inf)
                    zz=z.astype(complex)
                    finite=np.isfinite(zz).all()
                    residual=float(np.max(np.linalg.norm(mat@zz-zz*w,axis=0))/norm) if finite else float('nan')
                    orth=float(np.max(np.abs(zz.conj().T@zz-np.eye(n)))) if finite else float('nan')
                    limit=200*n*np.finfo(d.dtype).eps
                    tx.send(dict(precision=p,case=label,n=n,binary_scale=exponent,info=info.value,
                        ifail_count=np.count_nonzero(ifail),finite=finite,norm_residual_col2=residual,orth_max=orth,
                        nullified_off_diagonals=np.count_nonzero((ee==0)&(e!=0)),
                        passed=bool(finite and residual<=limit and orth<=limit)))
                rx,tx=mp.get_context("fork").Pipe(duplex=False)
                proc=mp.get_context("fork").Process(target=compute,args=(tx,))
                proc.start();tx.close();proc.join()
                try:
                    row=rx.recv()
                except EOFError:
                    row=dict(precision=p,case=label,n=n,binary_scale=exponent,info="STOP",
                             ifail_count="",finite=False,norm_residual_col2="",orth_max="",
                             nullified_off_diagonals=np.count_nonzero((ee==0)&(e!=0)),passed=False)
                rx.close();rows.append(row)
    with out.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
    fails=[(r['precision'],r['case'],r['binary_scale'],r['info']) for r in rows if not r['passed']]
    print(len(rows),len(fails),fails)


if __name__=='__main__':
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument('library',type=Path);cli.add_argument('--out',type=Path,required=True)
    cli.add_argument('--precision',default='dscz');args=cli.parse_args()
    run(Library(str(args.library.resolve())),args.out,args.precision)
